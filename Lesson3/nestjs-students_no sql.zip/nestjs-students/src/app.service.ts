import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  //getHello(): string {
  //  return 'Get Students.';
  getStud(): string {
      return 'А вот и студентики.';  
  }
}
